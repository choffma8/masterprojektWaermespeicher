"""
Build optimisation problems from PyPSA heat networks with Linopy.
"""

import pandas as pd
import pypsa
import logging
from pypsaheat import physics
from pypsaheat.optimization.constraints import (
    define_heat_store_constraints,
    heating_elements_constraints,
    heat_pumps_constraints,
    heat_load_constraints
)
from pypsaheat.optimization.variables import (
    define_heat_store_variables,
    heating_element_variables,
    heat_pump_variables,
)

logger = logging.getLogger(__name__)

def assign_ph_solution(n):

    """ Assigns the optimization results to the network's time series DataFrames.
    Parameters
    ----------
    n : pypsa.Network
        The PyPSA network object to which the optimization results will be assigned.
    """

    #assign heat store data
    n.heat_stores_t['T_layer'] = {hs: pd.DataFrame(index = n.snapshots) for hs in n.heat_stores.index}
    n.heat_stores_t['V_layer'] = {hs: pd.DataFrame(index = n.snapshots) for hs in n.heat_stores.index}
    for hs in n.heat_stores.index:
        if n.heat_stores.loc[hs, 'constant'] == 'volume':
            n.heat_stores_t['T_layer'][hs] = n.heat_stores_t[f'{hs}-T_layer']
            #n.heat_stores_t.pop(f'{hs}-T_layer')
        elif n.heat_stores.loc[hs, 'constant'] == 'temperature':
            n.heat_stores_t['V_layer'][hs] = n.heat_stores_t[f'{hs}-V_layer']
            #n.heat_stores_t.pop(f'{hs}-V_layer')

    #assign heat pump operational data
    for hp in n.heat_pumps.index:

        hs = n.heat_pumps.loc[hp, 'heat_store']

        if n.heat_stores.loc[hs, 'constant'] == 'volume':

            n_layer = n.heat_stores.loc[hs, 'N_layer']
            status = n.heat_pumps_t['status'].loc[:,hp]
            cp = physics.cp('water')
            T_nom = n.heat_pumps.loc[hp, 'T_nom']

            #Mass flow rate
            n.heat_pumps_t['m_flow'].loc[:, hp] = n.heat_pumps['m_nom'].loc[hp] * status
            
            T_supply = n.heat_pumps_t[f'{hp}-T_supply'].loc[:,hp]
            T_return = n.heat_pumps_t[f'{hp}-T_bin_layer_{hs}'][n_layer] #hier noch die richigen Layer abfragen, wenn ein und Auslasshöhe benötigt werden

            #Heat power output
            n.heat_pumps_t['p_heat'][(hp, T_nom)] = cp * n.heat_pumps_t['m_flow'].loc[:, hp] * (T_supply - T_return)

            #Electric power input      
            n.heat_pumps_t['p_elec'].loc[:, hp] = n.heat_pumps_t['p_heat'][(hp, T_nom)] / n.heat_pumps_t['COP'][(hp, T_nom)]
        
        elif n.heat_stores.loc[hs, 'constant'] == 'temperature':

            for T_layer in n.heat_pumps_t[f'{hp}-p'].columns:
                # Heat power output
                n.heat_pumps_t['p_heat'][(hp, T_layer)] = n.heat_pumps_t[f'{hp}-p'][T_layer]
            
            # Electric power input
            n.heat_pumps_t['p_elec'].loc[:, hp] = (n.heat_pumps_t['p_heat'][hp] / n.heat_pumps_t['COP'][hp]).sum(axis = 1)


    #assign heating element operational data
    n.heating_elements_t['p_heat'] = n.heating_elements_t['p'] * n.heating_elements['efficiency']
    n.heating_elements_t['p_elec'] = n.heating_elements_t['p']


class OptimizationAccessor(pypsa.optimization.optimize.OptimizationAccessor):

    """ Optimization accessor for heat networks.
    This class extends the PyPSA optimization accessor to include variables and constraints specific to heat networks.
    """

    def __init__(self, network):
        super().__init__(network)
        self.network = network
       
    def create_model(self, snapshots = None, *args, **kwargs):
        
        """
        Create the optimization model for the heat network.
        This method extends the base class method to include variables and constraints specific to heat networks.
        """

        sns = pypsa.pf._as_snapshots(self.network, snapshots)
        super().create_model(sns, *args,**kwargs)

        #adding variables and constranits for heat networks
        define_heat_store_variables(self.network, sns)
        define_heat_store_constraints(self.network, sns)
        heating_element_variables(self.network, sns)
        heating_elements_constraints(self.network, sns)
        heat_pump_variables(self.network, sns)
        heat_pumps_constraints(self.network, sns)
        heat_load_constraints(self.network, sns)

        return self.network.model

    def solve_model(self, *args, **kwargs):
        solution = super().solve_model(*args, **kwargs)
        if solution[1] == 'optimal':
            assign_ph_solution(self.network)
        return self.network.model


    def __call__(self,
                snapshots=None,
                solver_name="gurobi",
                solver_options={},
                **kwargs):
        self.create_model(snapshots=snapshots)
        self.solve_model(solver_name=solver_name, **solver_options, **kwargs)        
        return self.network
    
    def optimize_with_rolling_horizon(self, snapshots=None, horizon=100, overlap=0):
        """
        Optimizes the heat network in a rolling horizon fashion.

        Parameters
        ----------
        n : pypsa.Network
        snapshots : list-like
            Set of snapshots to consider in the optimization. The default is None.
        horizon : int
            Number of snapshots to consider in each iteration. Defaults to 100.
        overlap : int
            Number of snapshots to overlap between two iterations. Defaults to 0.
        

        Returns
        -------
        None
        """
        n = self.network

        if snapshots is None:
            snapshots = n.snapshots

        if horizon <= overlap:
            raise ValueError("overlap must be smaller than horizon")

        starting_points = range(0, len(snapshots), horizon - overlap)
        for i, start in enumerate(starting_points):
            end = min(len(snapshots), start + horizon)
            sns = snapshots[start:end]
            logger.info(
                f"Optimizing network for snapshot horizon [{sns[0]}:{sns[-1]}] ({i+1}/{len(starting_points)})."
            )

            if i:
                if not n.stores.empty:
                    n.stores.e_initial = n.stores_t.e.loc[snapshots[start - 1]]
                if not n.storage_units.empty:
                    n.storage_units.state_of_charge_initial = (
                        n.storage_units_t.state_of_charge.loc[snapshots[start - 1]]
                    )
                if not n.heat_stores.empty:
                    for hs in n.heat_stores.index:
                        if n.heat_stores.loc[hs, 'constant'] == 'volume':
                            n.heat_stores.at[hs, 'T_initial'] = n.heat_stores_t['T_layer'][hs].loc[snapshots[start - 1],:].to_list()
                        elif n.heat_stores.loc[hs, 'constant'] == 'temperature':
                            n.heat_stores.at[hs, 'V_initial'] = n.heat_stores_t['V_layer'][hs].loc[snapshots[start - 1],:].to_list()


            n.optimize(sns, solver_name="gurobi")