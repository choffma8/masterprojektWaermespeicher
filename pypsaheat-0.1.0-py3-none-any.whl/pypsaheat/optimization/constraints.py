"""
Define optimisation constraints from PyPSAheat networks with Linopy.
"""

import math
import pandas as pd
import xarray as xr
from xarray import DataArray, Dataset
from linopy import LinearExpression, merge
from pypsaheat import physics
import numpy as np


def heat_pumps_constraints(n, sns):
    """
    Define constraints for heat pumps.
    Parameters
    ----------
    n : pypsa.Network
    sns : snapshots
    """
    m = n.model
    sns_w = n.snapshot_weightings.stores.values[0]

    cp = physics.cp('water')

    for hp in n.heat_pumps.index:
        
        
        hs = n.heat_pumps.loc[hp, 'heat_store']
        bus = n.heat_pumps.loc[hp, 'bus0']
        if n.heat_stores.loc[hs, 'constant'] == 'volume':

            status = n.model.variables['HeatPump-status']
            
            ### binary constraints for heat pumps controlling the temperature variables of the heat store layers
            layer_num = n.heat_stores.loc[hs, 'N_layer']
            heat_store_layer_array = xr.DataArray(range(1, 1 + layer_num), dims=['layer'])
            T_bin_layer = n.model.variables[f'HeatPump-{hp}-T_bin_layer_{hs}']
            T_min = n.heat_stores.loc[hs, 'T_amb']
            T_max = n.heat_stores.loc[hs, 'T_max']

            # Constraint: T_bin_layer <= T_max * status
            m.add_constraints(
                lhs=T_bin_layer,
                rhs= T_max * status.sel(HeatPump=hp),
                name=f'HeatPump-{hp}-max_T_bin_layer_{hs}',
                sign='<='
            )

            # Constraint: T_bin_layer >= T_min * status
            m.add_constraints(
                lhs=T_bin_layer,
                rhs=T_min * status.sel(HeatPump=hp),
                name=f'HeatPump-{hp}-min_T_bin_layer_{hs}',
                sign='>='
            )

            #Constraining T_bin_layer to be equal to the temperature of the corresponding layer in the heat store when the heat pump is on
            T_layer = n.model.variables[f'HeatStore-{hs}-T_layer']
                
            m.add_constraints(
                lhs = T_layer - T_bin_layer,
                rhs = - status.sel(HeatPump=hp) * T_max + T_max,
                name = f'HeatPump-{hp}-T_bin_layer_eq_T_layer_{hs}_max',
                sign = '<='
            )

            m.add_constraints(
                lhs = T_layer - T_bin_layer,
                rhs = - status.sel(HeatPump=hp) * T_min + T_min,
                name = f'HeatPump-{hp}-T_bin_layer_eq_T_layer_{hs}_min',
                sign = '>='
            )

            #Constraining supply temperature of heat pump

            T_supply = n.model.variables[f'HeatPump-{hp}-T_supply']#.sel(HeatPump=hp)
            T_nom = n.heat_pumps.loc[hp, 'T_nom']

            m.add_constraints(
                lhs = T_supply - T_nom * status.sel(HeatPump=hp),
                rhs = 0,
                name = f'HeatPump-{hp}-T_supply_status',
                sign = '='
            )

            ###Defining nodal balance for heat pumps on electrical side    
            m_flow_hp = n.heat_pumps.loc[hp, 'm_nom'] #nominal mass flow of the heat pump
            T_nom = n.heat_pumps.loc[hp, 'T_nom']  #supply temperature of heat pump
            T_source = n.heat_pumps_t['T_source'].loc[:, hp] #source temperature of the heat pump
            heat_source = n.heat_pumps.loc[hp, 'heat_source']
            COP_model = n.heat_pumps.loc[hp, 'COP_model']
            COP = physics.COP(T_nom, T_source, heat_source = heat_source, cop_model = COP_model)
            n.heat_pumps_t['COP'][(hp, T_nom)] = COP


            hs = n.heat_pumps.loc[hp, 'heat_store'] #heat store connected to the heat pump
            layer_num = n.heat_stores.loc[hs, 'N_layer'] #number of layers of the heat store

            #getting labels of heat pump binary controlled temperature variables of the heat store layers
            comps = ['HeatStore'] #components to consider
            names = ["component", "name"]

            df_T_bin_layer_labels = pd.concat({c: m[f"HeatPump-{hp}-T_bin_layer_{hs}"].to_pandas() for c in comps}, axis=1, names=names) #geting labels in df
            df_T_bin_layer_labels = df_T_bin_layer_labels.loc[:, comps[0]][[layer_num]] #selecting only the labels of the lowest layer of the heat store
            T_bin_layer_labels = df_T_bin_layer_labels.loc[sns].values 

            # Create linear expression for heat pump
            ###TODO: Diesen ganzen Prozess in eine Funktion auslagern, da er sich mit dem der Heizungen und anderen Komponenten wiederholt
            coeffs_T_bin_layer = xr.DataArray(data = np.array([- sns_w * m_flow_hp * cp * 1/COP[sns]])[0], dims=("snapshot"), coords ={"snapshot": sns})
            vars_T_bin_layer = DataArray(T_bin_layer_labels, dims=("snapshot", "_term"), coords={"snapshot": sns})
            ds_T_bin_layer = Dataset({"coeffs": coeffs_T_bin_layer, "vars": vars_T_bin_layer})
            expr_T_bin_layer = LinearExpression(ds_T_bin_layer, m)

            # Get labels for "HeatPump-T_supply"
            #TODO: Funktion so entwicklen, dass COP auch als statische Variable berücksichtigt wird'
            #comps_T_supply = ['HeatPump']
            #names_T_supply = ["component", "name"]
            #df_T_supply_labels = pd.concat({c: m[f"{c}-{hp}-T_supply"].to_pandas() for c in comps_T_supply}, axis=1, names=names_T_supply)
            #T_supply_labels = df_T_supply_labels.loc[sns].values

            T_supply_var = m[f"HeatPump-{hp}-T_supply"]
            T_supply_labels = pd.DataFrame(data =T_supply_var.to_pandas().loc[sns], columns = [hp]).values  

            # Create linear expression for T_supply variable including COP
            coeffs_T_supply = xr.DataArray(data = np.array([sns_w * m_flow_hp * cp * 1/COP[sns]])[0], dims=("snapshot"), coords={"snapshot": sns})
            vars_T_supply = DataArray(T_supply_labels, dims=("snapshot", "_term"), coords={"snapshot": sns})
            ds_T_supply = Dataset({"coeffs": coeffs_T_supply, "vars": vars_T_supply})
            expr_T_supply = LinearExpression(ds_T_supply, m)

            # Combine both expressions with COP
            expr = expr_T_bin_layer + expr_T_supply

            # Mask for the correct bus
            mask = xr.DataArray(m.constraints['Bus-nodal_balance'].lhs.coords['Bus'] == bus, dims="Bus", coords={"Bus": m.constraints['Bus-nodal_balance'].lhs.coords['Bus']})

            # Subtract the expression from nodal balance at the correct bus
            m.constraints['Bus-nodal_balance'].lhs = m.constraints['Bus-nodal_balance'].lhs - expr.where(mask)

            ##### thermals side of heat pump #### 

            # Transport of heat pump mass flow through heat store layers
            # For each heat pump, add convective transport term to the heat store layer balance

            hs = n.heat_pumps.loc[hp, 'heat_store']
            m_flow_hp = n.heat_pumps.loc[hp, 'm_nom']
            layer_num = n.heat_stores.loc[hs, 'N_layer']
            cp = physics.cp('water')

            # Get T_bin_layer variable for this heat pump and heat store
            T_bin_layer = n.model.variables[f'HeatPump-{hp}-T_bin_layer_{hs}']

            # Use .roll and masking to vectorize the convective transport term
            T_bin_layer_upper = T_bin_layer.roll(layer=1)
            conv_term = sns_w * m_flow_hp * cp * (T_bin_layer_upper - T_bin_layer)

            # Mask for layers > 1 (since transport is from lower to higher layer)
            layer_coords = T_bin_layer.coords['layer']
            layer_array = T_bin_layer.coords['layer'].values
            mask_layers = xr.DataArray(layer_array > 1, coords=[layer_coords])

            # Only add convective term to layers > 1
            conv_term = conv_term.where(mask_layers)

            # Add this term to the layer balance constraint
            m.constraints[f'HeatStore-{hs}-layer_balance'].lhs = (
                m.constraints[f'HeatStore-{hs}-layer_balance'].lhs + conv_term
            )

            # For the top layer (layer == 1), add constraint for inflow from HeatPump (T_supply)
            # Prepare T_supply as in Bus-nodal_balance (see lines 111-115)
            # Get labels for "HeatPump-T_supply" variable for this heat pump
            
            #TODO: das hier kann beeser geschrieben werden. da es für die einzelnen Komponenten sehr individuell ist, muss der COde nicht allgemein sein
            #in df_T_supply_labels wird nur eine Spalte ausgewählt, da nur eine HeatPump betrachtet wird, es ist aber unnötig vorher eine DF zu erstellen, dass alle HeatPumps enthält
            # comps_T_supply = ['HeatPump']
            # names_T_supply = ["component", "name"]
            # df_T_supply_labels = pd.concat({c: m[f"{c}-{hp}-T_supply"].to_pandas() for c in comps_T_supply}, axis=1, names=names_T_supply)[[(comps_T_supply[0], hp)]]
            # T_supply_labels = df_T_supply_labels.loc[sns].values

            T_supply_var = m[f"HeatPump-{hp}-T_supply"]
            T_supply_labels = pd.DataFrame(data =T_supply_var.to_pandas().loc[sns], columns = [hp]).values

            # Create linear expression for T_supply variable
            coeffs_T_supply = xr.DataArray(data=np.array([sns_w * m_flow_hp * cp]), dims="_term")
            vars_T_supply = DataArray(T_supply_labels, dims=("snapshot", "_term"), coords={"snapshot": sns})
            ds_T_supply = Dataset({"coeffs": coeffs_T_supply, "vars": vars_T_supply})
            expr_T_supply = LinearExpression(ds_T_supply, m)

            expr = expr_T_supply - sns_w * m_flow_hp * cp * T_bin_layer.sel(layer=1)

            # Mask for the top layer (layer == 1)
            mask_top_layer = xr.DataArray(layer_array == 1, coords=[layer_coords])

            # Add this term to the layer balance constraint for the top layer
            m.constraints[f'HeatStore-{hs}-layer_balance'].lhs = (
                m.constraints[f'HeatStore-{hs}-layer_balance'].lhs + expr.where(mask_top_layer)
            )

        elif n.heat_stores.loc[hs, 'constant'] == 'temperature':
            
            p_nom = n.heat_pumps.loc[hp, 'p_nom'] #nominal power of the heat pump

            # Limit heat pump power between 0 and p_nom
            hp_p_layer = m.variables[f'HeatPump-{hp}-p']
            heat_pump_sum = hp_p_layer.sum(dim='layer')
            m.add_constraints(lhs=heat_pump_sum, sign='>=', rhs=0, name=f'HeatPump-{hp}-fix-p-lower')
            m.add_constraints(lhs=heat_pump_sum, sign='<=', rhs=p_nom, name=f'HeatPump-{hp}-fix-p-upper')
            #Limit heat pump power to zero for each layer HP
            m.add_constraints(lhs=hp_p_layer, sign='>=', rhs=0, name=f'HeatPump-{hp}-fix-p-layer-lower')
            m.add_constraints(lhs=hp_p_layer, sign='<=', rhs=p_nom, name=f'HeatPump-{hp}-fix-p-layer-upper')


            ###Defining nodal balance for heat pumps on electrical side
            hp_p_layer = m.variables[f'HeatPump-{hp}-p']
            layer_coords = hp_p_layer.coords['layer']
            layer_array = layer_coords.values

            T_source = n.heat_pumps_t['T_source'].loc[:, hp] #source temperature of the heat pump
            heat_source = n.heat_pumps.loc[hp, 'heat_source']
            COP_model = n.heat_pumps.loc[hp, 'COP_model']

            #COP_hp_layer = pd.DataFrame(0, index=n.snapshots, columns=pd.MultiIndex.from_product([[hp], layer_array], names=["HeatPump", "layer"]))
            invert_cop_values_list = []

            # Iterate over each temperature in layer_coords
            for T_layer in layer_coords.values:
                # Calculate the COP for the layer temperature
                cop_value = physics.COP(up_T=T_layer, low_T=n.heat_pumps_t['T_source'].loc[:, hp], heat_source=heat_source, cop_model=COP_model)
                #COP_hp_layer[(hp, T_layer)] = cop_value
                n.heat_pumps_t['COP'][(hp, T_layer)] = cop_value
                invert_cop_values_list.append(1/cop_value[sns]) #values for nodal balance constraint

            # Create a DataArray for cop_values with appropriate dimensions and coordinates
            cop_values = xr.DataArray(invert_cop_values_list, dims=["layer", "snapshot"], coords={"layer": layer_coords, "snapshot": sns})

            # Multiply hp_p_layer with the calculated COP values
            expr = hp_p_layer * cop_values
            # Sum over the layer dimension to create linear expression without layer dimension
            hp_expr = expr.sum('layer')

            # Mask for the correct bus
            mask_bus = xr.DataArray(m.constraints['Bus-nodal_balance'].lhs.coords['Bus'] == bus, dims="Bus", coords={"Bus": m.constraints['Bus-nodal_balance'].lhs.coords['Bus']})
            mask_non_bus = ~mask_bus

            # Subtract the expression from nodal balance at the correct bus
            bus_nodal_balance_lhs = m.constraints['Bus-nodal_balance'].lhs
            m.constraints['Bus-nodal_balance'].lhs = bus_nodal_balance_lhs.where(mask_non_bus) + (bus_nodal_balance_lhs - hp_expr).where(mask_bus)


            ###Defining nodal balance for heat pumps on thermal side
            m.constraints[f'HeatStore-{hs}-layer_balance'].lhs = m.constraints[f'HeatStore-{hs}-layer_balance'].lhs + sns_w * hp_p_layer


def heating_elements_constraints(n, sns):
    """
    Define constraints for heating elements.
    Parameters
    ----------
    n : pypsa.Network
    sns : snapshots
    """

    if n.heating_elements.index.empty:
        return


    m = n.model
    p = n.model.variables['HeatingElement-p']
    sns_w = n.snapshot_weightings.stores.values[0]

    # Limit heating element power between 0 and p_nom
    for he in n.heating_elements.index:
        p_nom = n.heating_elements.loc[he, 'p_nom']
        m.add_constraints(
            lhs=p.sel(HeatingElement=he),
            rhs=0,
            name=f'HeatingElement-{he}-fix-p-lower',
            sign='>='
        )
        m.add_constraints(
            lhs=p.sel(HeatingElement=he),
            rhs=p_nom,
            name=f'HeatingElement-{he}-fix-p-upper',
            sign='<='
        )



    ##electrical side
    cbuses = n.df('HeatingElement')['bus0'].rename("Bus")
    exprs = p.groupby(cbuses).sum()
    m.constraints['Bus-nodal_balance'].lhs = m.constraints['Bus-nodal_balance'].lhs - exprs

    ####################################################
    ## thermal side
    he_dic = {}

    for he in n.heating_elements.index:

        he_eff = n.heating_elements.loc[he,'efficiency']
        heat_store_name = n.heating_elements.loc[he,'heat_store']

        if n.heat_stores.loc[heat_store_name,'constant'] == 'volume':

            heating_element_depth = n.heating_elements.loc[he,'depth']
            heat_store_nlayer = n.heat_stores.loc[heat_store_name,'N_layer']
            heat_store_height = n.heat_stores.loc[n.heating_elements.loc[he,'heat_store'],'height']
            heat_store_nlayers = n.heat_stores.loc[n.heating_elements.loc[he,'heat_store'],'N_layer']
            layer_height = heat_store_height / heat_store_nlayers

            n_layer_heated = math.ceil(heating_element_depth/ layer_height)    #number layer heated by the heating element
            n_full_layer_heated = n_layer_heated - 1 #number of layer fully penetrated by the heating element

            if n_full_layer_heated == 0:
                p_pu_full_layer = 0
            else:
                p_pu_full_layer = round(((layer_height * n_full_layer_heated) / heating_element_depth) / n_full_layer_heated, 2)  #power per unit in the fully penetrated layer

            #creating list for power per unit of the heating element in each layer
            he_layer_dic = {}
            for i in range(1, 1 + n_full_layer_heated):
                he_layer_dic[i] = p_pu_full_layer

            ##depth of the lowest layer heated by the heating element
            depth_lowest_layer = heating_element_depth - layer_height * n_full_layer_heated
            p_pu_lowest_layer = round(he_eff * depth_lowest_layer / heating_element_depth, 2)  #power per unit in the lowest layer heated by the heating element
            he_layer_dic[n_layer_heated] = p_pu_lowest_layer

            # adding zeros for non-heated layer
            for layer in range(1, 1 + heat_store_nlayer):
                if layer not in he_layer_dic:
                    he_layer_dic[layer] = 0

            he_dic[he] = he_layer_dic

        ####################################################    

            comps = ['HeatingElement'] #components to consider
            names = ["component", "name"]
            df_p_lables = pd.concat({c: m[f"{c}-p"].to_pandas() for c in comps}, axis=1, names=names)[[(comps[0], he)]]
            p_lables = df_p_lables.loc[sns].values

            exprs = [] #list for linear expressions

            #creating expressions with dims for each layer of 'HeatStore'
            for l in range(1, heat_store_nlayer + 1):
                coeffs = xr.DataArray(data= np.array([sns_w * he_layer_dic[l]]), dims="_term") #coefficients for each layer (share of heating element power for each layer)
                vars = DataArray(p_lables, #variablen associated with the heating element with dimension "snapshot" ("_term" is required as default)
                            dims=("snapshot", "_term"),
                            coords={"snapshot": sns},
                        )
                
                ds = Dataset({"coeffs": coeffs, "vars": vars}) #creating dataset with linear expressions per layer 
                exprs.append(LinearExpression(ds, m)) #adding linear expressions to the list (each element in list represent one layer)

            #merging expressions for all layers    
            if len(exprs):
                exprs = merge(exprs, dim="layer") #introducing layer dimension to the expressions
                exprs = exprs.assign_coords(layer=range(1, len(exprs.data.layer) + 1)) #assign coords to layer dimension (each layer has its own coordinate)

            #changing constraint of heat store layer balance
            m.constraints[f'HeatStore-{heat_store_name}-layer_balance'].lhs = m.constraints[f'HeatStore-{heat_store_name}-layer_balance'].lhs + exprs


        elif n.heat_stores.loc[heat_store_name,'constant'] == 'temperature':

            T_max = max(n.heat_stores.loc[heat_store_name,'T_layer'])

            comps = ['HeatingElement'] #components to consider
            names = ["component", "name"]
            df_p_lables = pd.concat({c: m[f"{c}-p"].to_pandas() for c in comps}, axis=1, names=names)[[(comps[0], he)]]
            p_lables = df_p_lables.loc[sns].values

            exprs = [] #list for linear expressions

            #creating expressions with dims for each layer of 'HeatStore'
            coeffs = xr.DataArray(data= np.array([sns_w * he_eff]), dims="_term") #coefficients for each layer (share of heating element power for each layer)
            vars = xr.DataArray(p_lables, #variablen associated with the heating element with dimension "snapshot" ("_term" is required as default)
                            dims=("snapshot", "_term"),
                            coords={"snapshot": sns},
                        )
            
            ds = xr.Dataset({"coeffs": coeffs, "vars": vars}) #creating dataset with linear expressions per layer 
            expr = LinearExpression(ds, m) #adding linear expressions to the list (each element in list represent one layer)

            V_layer = n.model.variables[f'HeatStore-{heat_store_name}-V_layer']
            layer_coords = V_layer.coords['layer']
            layer_array = V_layer.coords['layer'].values

            #creating masks for hgihest layer and all other layers
            mask_highest_layer = xr.DataArray(layer_array == T_max, coords=[layer_coords])
            mask_exclude_highest_layer = xr.DataArray(layer_array != T_max, coords=[layer_coords])

            layer_balance_lhs = n.model.constraints[f'HeatStore-{heat_store_name}-layer_balance'].lhs
            n.model.constraints[f'HeatStore-{heat_store_name}-layer_balance'].lhs = layer_balance_lhs.where(mask_exclude_highest_layer) + (layer_balance_lhs + expr).where(mask_highest_layer)

def get_heat_load_data_hs(n, hs):
    """
    Get heat load data for a specific heat store.
    Parameters
    ----------
    n : pypsa.Network
    hs : str
        Name of the heat store.
    Returns
    -------
    dict
        Dictionary containing mass flow demand, T_demand, T_diff_return, outlet_height, and inlet_height.
    """

    load_at_hs = n.heat_loads.loc[n.heat_loads['heat_store'] == hs].index[0]
    
    T_demand = n.heat_loads.loc[load_at_hs, 'T_demand']
    T_diff_return = n.heat_loads.loc[load_at_hs, 'T_diff_return']
    outlet_height = n.heat_loads.loc[load_at_hs, 'outlet_height']
    inlet_height = n.heat_loads.loc[load_at_hs, 'inlet_height']
    p_set = n.heat_loads_t['p_set'][load_at_hs]
    cp = physics.cp('water')

    mass_flow = p_set/ (cp * T_diff_return)
    
    return {'mass_flow_demand': mass_flow, 'T_demand': T_demand, 'T_diff_return': T_diff_return,  'outlet_height': outlet_height, 'inlet_height': inlet_height}



def define_heat_store_constraints(n, sns):
    """
    Define constraints for heat stores.
    Parameters
    ----------
    n : pypsa.Network
    sns : snapshots
    """
    
    cp = physics.cp('water')
    den = physics.den('water')
    k = physics.k('water') /1000

    sns_w = n.snapshot_weightings.stores[sns].values[0]

    for hs in n.heat_stores.index:
        
        #HeatStore specifications
        height = n.heat_stores.loc[hs,'height']
        A_base = n.heat_stores.loc[hs,'base']
        T_amb = n.heat_stores.loc[hs, 'T_amb']
        U_wall = n.heat_stores.loc[hs, 'U_wall']/1000 #heat conductivity of heat store wall in kW/(m2*K)
        circumference = physics.get_circumference(A_base)

        if n.heat_stores.loc[hs,'constant'] == 'volume':

            #HeatStore specifications
            n_layer = n.heat_stores.loc[hs,'N_layer']
            layer_height = height / n_layer
            T_amb = n.heat_stores.loc[hs, 'T_amb']
            A_lateral_layer = circumference * layer_height  #lateral surface area of each layer
            U_wall = n.heat_stores.loc[hs, 'U_wall']/1000 #heat conductivity of heat store wall in kW/(m2*K)


            #HeatStore variables 
            T_layer = n.model.variables[f'HeatStore-{hs}-T_layer']
            layer_coords = T_layer.coords['layer']
            layer_array = T_layer.coords['layer'].values          

            # Add constraints for the heat store layer balance
            T_upper = T_layer.roll(layer = 1)
            T_lower = T_layer.roll(layer = -1)

            # Energy balance terms
            if n.heat_stores.loc[hs, 'cyclic'] == True:
                energy_balance_term = cp * den * A_base * layer_height * (T_layer - T_layer.roll(snapshot = 1))
                energy_balance_term_initial = 0
            else:
                energy_balance_term = cp * den * A_base * layer_height * (T_layer - T_layer.roll(snapshot = 1)).where(T_layer.coords['snapshot'] != sns[0])

                #### Energy balance with T_initial condition for the first timestep
                T_init_lst = n.heat_stores.loc[hs, 'T_initial']

                # Ensure T_init_lst is a list with length n_layer
                if not isinstance(T_init_lst, (list, tuple, np.ndarray, pd.Series)):
                    T_init_lst = [T_init_lst] * n_layer
                elif len(T_init_lst) < n_layer:
                    T_init_lst = list(T_init_lst) + [T_init_lst[-1]] * (n_layer - len(T_init_lst))


                for l, T_init in enumerate(T_init_lst, start=1):
                    expr = cp * den * A_base * layer_height * (T_layer - T_init).where(T_layer.coords['snapshot'] == sns[0]).where(T_layer.coords['layer'] == l)
                    energy_balance_term_initial = expr + energy_balance_term_initial

            conduction_term_from_upper = (sns_w * k * A_base * (T_upper - T_layer) / layer_height).where(xr.DataArray(layer_array > 1, coords=[layer_coords]))
            conduction_term_to_lower = (sns_w * k * A_base * (T_lower - T_layer) / layer_height).where(xr.DataArray(layer_array < n_layer, coords=[layer_coords]))
            heat_loss_term_middle_layer = (sns_w * U_wall * A_lateral_layer * (T_layer - T_amb)).where(xr.DataArray((layer_array > 1) & (layer_array < n_layer), coords=[layer_coords]))
            heat_loss_term_top_layer =  (sns_w * U_wall * (A_lateral_layer + A_base) * (T_layer - T_amb)).where(xr.DataArray(layer_array == 1, coords=[layer_coords]))
            heat_loss_term_bottom_layer = (sns_w * U_wall * (A_lateral_layer + A_base) * (T_layer - T_amb)).where(xr.DataArray(layer_array == n_layer, coords=[layer_coords]))

    
            ### creating the constraint
            lhs = - energy_balance_term - energy_balance_term_initial + conduction_term_from_upper + conduction_term_to_lower - heat_loss_term_middle_layer - heat_loss_term_top_layer - heat_loss_term_bottom_layer
            rhs = 0

            n.model.add_constraints(lhs = lhs, rhs = rhs, name = f"HeatStore-{hs}-layer_balance", sign = '=')

            # #Add constraints for the heat store minimum layer temperature
            # # Mask for the highest layer (layer == 1)
            # mask_highest_layer = xr.DataArray(layer_array == 1, coords=[layer_coords])

            # ### Constraint: T_layer >= T_demand for highest layer, T_layer >= T_amb for other layers
            # min_temp = xr.DataArray(np.where(mask_highest_layer, T_demand, T_amb), coords=[layer_coords])

            # n.model.add_constraints(
            #     lhs=T_layer,
            #     rhs=min_temp,
            #     name=f"HeatStore-{hs}-min_layer_temp",
            #     sign=">="
            # )

            T_max = n.heat_stores.loc[hs, 'T_max']
            # Add constraints for the maximum layer temperature (all layers <= T_max)
            max_temp = xr.DataArray(np.full_like(layer_array, T_max, dtype=float), coords=[layer_coords])
            n.model.add_constraints(
                lhs=T_layer,
                rhs=max_temp,
                name=f"HeatStore-{hs}-max_layer_temp",
                sign="<="
            )

        elif n.heat_stores.loc[hs,'constant'] == 'temperature':

            T_return = n.heat_stores.loc[hs, 'T_return'] # TODO: auf T_diff_return umstellen
            total_volume = height * A_base
            n_layer = len(n.heat_stores.loc[hs,'T_layer'])
            T_max = max(n.heat_stores.loc[hs,'T_layer'])
            T_min = min(n.heat_stores.loc[hs,'T_layer'])

            #Add constraints for the heat store total volume
            n.model.add_constraints(
                lhs=n.model.variables[f'HeatStore-{hs}-V_layer'].sum(dim='layer'),
                rhs=total_volume,
                name=f'HeatStore-{hs}-fix-volume-upper',
                sign='<='
            )

            #Add constraints for the heat store minimum volume
            n.model.add_constraints(
                lhs=n.model.variables[f'HeatStore-{hs}-V_layer'],
                rhs=0,
                name=f'HeatStore-{hs}-fix-volume-lower',
                sign='>='
            )

            ### Layer balance for heat stores with constant temperature ###

            V_layer = n.model.variables[f'HeatStore-{hs}-V_layer']
            layer_coords = V_layer.coords['layer']
            layer_array = V_layer.coords['layer'].values

            p_inter_layer = n.model.variables[f'HeatStore-{hs}-p_internal']
            mask_exclude_highest_layer = xr.DataArray(layer_array != T_max, coords=[layer_coords])
            mask_exclude_lowest_layer = xr.DataArray(layer_array != T_min, coords=[layer_coords])
            layer_internal_out = p_inter_layer.where(mask_exclude_lowest_layer)
            layer_internal_in = p_inter_layer.roll(layer = 1).where(mask_exclude_highest_layer)

            # Inititalizing energy balance terms
            if n.heat_stores.loc[hs, 'cyclic'] == True:
                energy_balance_term = (layer_coords - T_return) * cp * den * (-V_layer + V_layer.roll(snapshot = 1))
                energy_balance_term_initial = 0
            else:
                energy_balance_term = (layer_coords - T_return) * cp * den * (-V_layer + V_layer.roll(snapshot = 1)).where(V_layer.coords['snapshot'] != sns[0])

                # Energy balance with V_initial condition for the first timestep
                V_init_lst = n.heat_stores.loc[hs, 'V_initial']
    
                # Ensure V_init_lst is a list with length n_layer
                if not isinstance(V_init_lst, (list, tuple, np.ndarray, pd.Series)):
                    V_init_lst = [V_init_lst] * n_layer
                elif len(V_init_lst) < n_layer:
                    V_init_lst = list(V_init_lst) + [V_init_lst[-1]] * (n_layer - len(V_init_lst))

                energy_balance_term_initial = 0
                i = 0    
                for V_init in V_init_lst:
                    l = layer_array[i]
                    i += 1
                    expr = (layer_coords - T_return) * cp * den * (-V_layer + V_init).where(V_layer.coords['snapshot'] == sns[0]).where(V_layer.coords['layer'] == l)
                    energy_balance_term_initial += expr

            #Heat losses
            loss_lateral_layer = sns_w * U_wall * circumference * (V_layer/A_base) * (layer_coords - T_amb)
            loss_top_bottom_layer = sns_w * U_wall * 2 * A_base/n_layer * (layer_coords - T_amb)
            total_loss_layer = loss_lateral_layer + loss_top_bottom_layer

            #Creating the constraint
            lhs = energy_balance_term + energy_balance_term_initial + layer_internal_in - layer_internal_out - total_loss_layer 
            n.model.add_constraints(
                lhs = lhs,
                rhs = 0,
                name = f'HeatStore-{hs}-layer_balance',
                sign = '='
            )

            #Add constranit for lower limit of internal layer transport
            n.model.add_constraints(
                lhs = p_inter_layer,
                rhs = 0,
                name = f'HeatStore-{hs}-internal-lower',
                sign = '>='
            )

def get_heat_load_data(n, hl):
    """
    Get heat load data for a specific heat store.
    Parameters
    ----------
    n : pypsa.Network
    hs : str
        Name of the heat store.
    Returns
    -------
    dict
        Dictionary containing mass flow demand, T_demand, T_diff_return, outlet_height, and inlet_height.
    """
    
    if hl in n.heat_loads_t['T_demand'].columns:
        T_demand = n.heat_loads_t['T_demand'].loc[:,hl]
    else:
        T_demand = pd.Series(index=n.snapshots, data=n.heat_loads.loc[hl, 'T_demand'])

    T_diff_return = n.heat_loads.loc[hl, 'T_diff_return']
    outlet_height = n.heat_loads.loc[hl, 'outlet_height']
    inlet_height = n.heat_loads.loc[hl, 'inlet_height']
    p_set = n.heat_loads_t['p_set'][hl]
    cp = physics.cp('water')

    mass_flow = p_set/ (cp * T_diff_return)
    
    return {'p_set': p_set, 'mass_flow_demand': mass_flow, 'T_demand': T_demand, 'T_diff_return': T_diff_return,  'outlet_height': outlet_height, 'inlet_height': inlet_height}

def heat_load_constraints(n, sns):
    """
    Define constraints for heat loads.
    Parameters
    ----------
    n : pypsa.Network
    """

    sns_w = n.snapshot_weightings.stores[sns].values[0]
    cp = physics.cp('water')

    for hs in n.heat_stores.index:

        T_amb = n.heat_stores.loc[hs, 'T_amb']


        if n.heat_stores.loc[hs, 'constant'] == 'volume':
        
            # Get T_layer variable for this heat store
            T_layer = n.model.variables[f'HeatStore-{hs}-T_layer']
            layer_coords = T_layer.coords['layer']
            layer_array = layer_coords.values

            T_lower = T_layer.roll(layer = -1)
            # Iterate over all heat loads connected to this hea
            df_T_min = pd.DataFrame(data = T_amb, index = n.snapshots, columns=layer_array)


            for hl in n.heat_loads[n.heat_loads['heat_store'] == hs].index:

                # Load information
                load_data = get_heat_load_data(n,hl)
                p_set = load_data['p_set']
                m_load = xr.DataArray(load_data['mass_flow_demand'])
                T_demand = load_data['T_demand']
                outlet_layer = physics.get_inlet_outlet_layer(n, load_data['outlet_height'], hs)
                inlet_layer = physics.get_inlet_outlet_layer(n, load_data['inlet_height'], hs)
                T_diff_return = load_data['T_diff_return']

                if n.heat_loads.loc[hl, 'internal_exchange'] == False:
                    # Add constraints for heat load to layer Balance constraint
                    layer_below_outlet = xr.DataArray(layer_array >= outlet_layer, coords=[layer_coords])
                    layer_above_inlet = xr.DataArray(layer_array < inlet_layer, coords=[layer_coords])

                    convection_term = sns_w * m_load * cp * (T_lower - T_layer).where(layer_below_outlet & layer_above_inlet)

                    ### inflow from load
                    mask_inlet_layer = xr.DataArray(layer_array == inlet_layer, coords=[layer_coords])   
                    inflow_from_load = sns_w * m_load * cp * (T_layer.roll(layer = -1) - T_diff_return - T_layer).where(mask_inlet_layer)

                    # Add convection term to layer balance constraint
                    n.model.constraints[f'HeatStore-{hs}-layer_balance'].lhs = n.model.constraints[f'HeatStore-{hs}-layer_balance'].lhs + convection_term + inflow_from_load

                elif n.heat_loads.loc[hl, 'internal_exchange'] == True:
                    layer_below_outlet = xr.DataArray(layer_array >= outlet_layer, coords=[layer_coords])
                    layer_above_inlet = xr.DataArray(layer_array <= inlet_layer, coords=[layer_coords])
                    layer_difference =  inlet_layer - outlet_layer
                    demand_from_layer = xr.DataArray(p_set[sns]/layer_difference, coords=[sns])
                    n.model.constraints[f'HeatStore-{hs}-layer_balance'].lhs = n.model.constraints[f'HeatStore-{hs}-layer_balance'].lhs - demand_from_layer.where(layer_below_outlet & layer_above_inlet)

                df_T_min[outlet_layer] = np.maximum(df_T_min[outlet_layer], T_demand)


            # Create a DataArray for the minimum temperature constraints
            T_min = xr.DataArray(df_T_min.loc[sns,:].values, coords=[sns, layer_coords], dims=["snapshot", "layer"])

            # Add constraints to ensure T_layer >= T_min for each layer
            n.model.add_constraints(
                lhs=T_layer,
                rhs=T_min,
                name=f"HeatStore-{hs}-min_layer_temp",
                sign=">="
            )




        elif n.heat_stores.loc[hs, 'constant'] == 'temperature':
            #Create dataframe for heat loads per layer
            df_heat_loads_per_layer = pd.DataFrame(0, index=n.snapshots, columns=n.heat_stores.loc[hs, 'T_layer'])
            for hl in n.heat_loads[n.heat_loads['heat_store'] == hs].index:
                # hs = n.heat_loads.loc[hl, 'heat_store']
                # if n.heat_stores.loc[hs, 'constant'] == 'temperature':
                T_level = n.heat_stores.loc[hs, 'T_layer']
                if n.heat_loads.loc[hl, 'T_demand'] is None:
                    T_demand = n.heat_loads_t['T_demand'][hl]
                elif isinstance(n.heat_loads.loc[hl, 'T_demand'], (int, float)):
                    T_demand = pd.Series(index=n.snapshots, data=n.heat_loads.loc[hl, 'T_demand'])

                p_set = n.heat_loads_t['p_set'][hl]

                df = pd.DataFrame(columns = T_level)
                df['T_demand'] = T_demand

                # Iterate over each column in the DataFrame (excluding 'T_sink')
                for col in df.columns.drop('T_demand'):
                    col_value = int(col)

                # Update the column values based on the condition
                    df[col] = df.apply(lambda row: p_set[row.name] if col_value >= row['T_demand'] else 0, axis=1)

                #Check if heat store temperature is above T_sink
                if T_demand.max() > max(T_level):
                    raise ValueError("Heat load temperature is higher than maximum heat store temperature. Please increase heat store temperature or decrease heat load temperature.")


                # Check for duplicate values in columns with lower temperature
                for index, row in df.iterrows():
                    for col in df.columns.drop('T_demand'):
                        col_value = int(col)
                        if df.at[index, col] != 0:
                            for lower_col in df.columns.drop('T_demand'):
                                lower_col_value = int(lower_col)
                                if lower_col_value < col_value and df.at[index, lower_col] == df.at[index, col]:
                                    df.at[index, col] = 0
                                    break
                df_heat_loads_per_layer += df.drop(columns = 'T_demand')
            
            #Create demand constraints for heat loads per layer
            for T in n.heat_stores.loc[hs, 'T_layer']:
                V_layer = n.model.variables[f'HeatStore-{hs}-V_layer']
                layer_coords = V_layer.coords['layer']
                layer_array = V_layer.coords['layer'].values
                mask_T_layer = xr.DataArray(layer_array == T, coords=[layer_coords])
                mask_non_t_layer = xr.DataArray(layer_array != T, coords=[layer_coords])

                layer_balance_lhs = n.model.constraints[f'HeatStore-{hs}-layer_balance'].lhs
                n.model.constraints[f'HeatStore-{hs}-layer_balance'].lhs = layer_balance_lhs.where(mask_non_t_layer) + (layer_balance_lhs - df_heat_loads_per_layer.loc[sns, T].values).where(mask_T_layer)