"""
Define optimisation variables from PyPSA heat networks with Linopy.
"""

import xarray as xr

def define_heat_store_variables(n, sns):
    """
    Define variables for heat stores.
    Parameters
    ---------- 
    n : pypsa.Network
    sns : snapshots
    """
    sns_array = xr.DataArray(sns, dims=['snapshot'])

    for hs in n.heat_stores.index:

        if n.heat_stores.loc[hs,'constant'] == 'volume':

            heat_store_layer_array = xr.DataArray(range(1, 1 + n.heat_stores.loc[hs,'N_layer']), dims=['layer'])
            # Add variables for each heat store
            n.model.add_variables(
                name=f'HeatStore-{hs}-T_layer',
                coords= [sns_array, heat_store_layer_array]
                    )
            
        elif n.heat_stores.loc[hs,'constant'] == 'temperature':
            # Add variables for each heat store
            heat_store_layer_array = xr.DataArray(n.heat_stores.loc[hs, 'T_layer'], dims=['layer'])
            n.model.add_variables(
                name=f'HeatStore-{hs}-V_layer',
                coords= [sns_array, heat_store_layer_array]
                    )
        
            #Add variabbles for layer interactions (energy trasnmission to lower layers)
            n.model.add_variables(
                name=f'HeatStore-{hs}-p_internal',
                coords= [sns_array, heat_store_layer_array] #no variable for the lowest layer
                    )


def heating_element_variables(n, sns):
    """
    Define variables for heating elements.
    Parameters
    ----------
    n : pypsa.Network
    sns : snapshots
    """
    if n.heating_elements.empty != True:
        sns_array = xr.DataArray(sns, dims=['snapshot'])
        heating_element_array = xr.DataArray(n.heating_elements.index, dims=['HeatingElement'])
    
        n.model.add_variables(name='HeatingElement-p', coords=[sns_array, heating_element_array])

def heat_pump_variables(n, sns):
    """
    Define variables for heat pumps.
    Parameters
    ----------
    n : pypsa.Network
    sns : snapshots

    """
    sns_array = xr.DataArray(sns, dims=['snapshot'])

    #### Heat pump variables for heat pumps with heat stores of constant volume ####

    heat_stores_con_volume = n.heat_stores[n.heat_stores['constant'] == 'volume'].index
    heat_pump_con_volume = n.heat_pumps[n.heat_pumps['heat_store'].isin(heat_stores_con_volume)].index

    heat_pump_array = xr.DataArray(heat_pump_con_volume, dims=['HeatPump'])

    #status variable for heat pumps
    for hp in heat_pump_con_volume:
        n.model.add_variables(name='HeatPump-status', binary = True , coords=[sns_array, heat_pump_array])

    #supply temperature variable for heat pumps
    for hp in heat_pump_con_volume:
        hp_array = xr.DataArray([hp], dims=['HeatPump'])
        n.model.add_variables(name=f'HeatPump-{hp}-T_supply', coords=[sns_array, hp_array])

    #binary constraint temperature variables for heat pumps
    for hp in heat_pump_con_volume:
        hs = n.heat_pumps.loc[hp, 'heat_store']

        layer_num = n.heat_stores.loc[hs, 'N_layer']
        heat_store_layer_array = xr.DataArray(range(1, 1 + layer_num), dims=['layer'])
        n.model.add_variables(
            name=f'HeatPump-{hp}-T_bin_layer_{hs}',
            coords=[sns_array, heat_store_layer_array]
        )

    #### Heat pump variables for heat pumps with heat stores of constant temperature ####
    heat_stores_con_temperature = n.heat_stores[n.heat_stores['constant'] == 'temperature'].index
    heat_pump_con_temp = n.heat_pumps[n.heat_pumps['heat_store'].isin(heat_stores_con_temperature)].index

    # Für jede Wärmepumpe mit Speicher konstanter Temperatur Variable mit snapshot und layer (T_layer)
    for hp in heat_pump_con_temp:
        T_max = n.heat_pumps.loc[hp, 'T_max']
        hs = n.heat_pumps.loc[hp, 'heat_store']
        supplied_layers = [T for T in n.heat_stores.loc[hs, 'T_layer'] if T <= T_max]
        heat_store_layer_array = xr.DataArray(supplied_layers, dims=['layer'])
        n.model.add_variables(
            name=f'HeatPump-{hp}-p',
            coords=[sns_array, heat_store_layer_array]
        )