from matplotlib import pyplot as plt
import numpy as np

def plot_stratified_heat_store(n, hs, sns, figsize=(8, 6), **kwargs):
    """
    Plots the volume of each layer of a stratified heat store over time as a stacked area plot.
    Heat store must be of constant temperature.
    Parameters:
    n : pypsa.Network
        The PyPSA network containing the heat store.
    hs : str
        The name of the heat store to plot.
    sns : list-like,
        The snapshots to include in the plot.
    figsize : tuple, optional
		The size of the figure. Default is (8, 6).
    **kwargs : additional keyword arguments
        Additional keyword arguments to pass to the stackplot function.
    """

    #preparing data
    v = n.heat_stores.loc[hs,'height'] * n.heat_stores.loc[hs,'base']
    T_return = n.heat_stores.loc[hs,'T_return']
    df = n.heat_stores_t['V_layer'][hs].loc[sns,:]
    df = df.assign(T_return = v - df.sum(axis = 1)).clip(lower = 0)
    df = df.iloc[:, ::-1]
    
    #specifing colors based on temperatures
    temps = np.array(n.heat_stores.loc[hs,'T_layer'] + [T_return])
    normalized_temps = (temps - temps.min())/ (temps.max() - temps.min())
    cmap = plt.cm.RdYlBu
    colors = cmap(normalized_temps)
    
    #plotting data
    fig, ax = plt.subplots(figsize=figsize)
    ax.stackplot(df.index, df.T.values.tolist(), labels = df.columns, colors = colors,**kwargs)
    ax.legend(title='Layer', loc='lower left', reverse = True)

def plot_heat_map(data):
	'''Plotting heat map for dataseries with 8760 hours '''
	from matplotlib import pyplot as plt
	import numpy as np
	import seaborn as sns
	
	#preparing data for creating heatmap by shaping it into np.arrays 
	heatmap_data = data
	heatmap_data = heatmap_data.values.reshape(365, int(len(heatmap_data)/365))
	heatmap_data = np.rot90(heatmap_data)
	heatmap_data = np.flipud(heatmap_data)
	
	#plotting data by multidimensional np.arrays
	fig, ax = plt.subplots(figsize = (12,3) )
	ax = sns.heatmap(heatmap_data, cmap="Blues")
	ax.invert_yaxis()
	#ax.set_xticklabels(data.index.dt.strftime('%d-%m'))

	ax.set_xlabel('day of the year')
	ax.set_ylabel('hour of the day')
	plt.locator_params(axis='y', nbins=8)
	plt.locator_params(axis='x', nbins=13)
	ax.tick_params(direction='out', length=3, width=0.5)