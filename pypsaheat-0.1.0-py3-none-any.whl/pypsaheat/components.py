import pypsa
import pandas as pd
import numpy as np
from pypsaheat.physics import (stratified_storage_losses, storage_dimensions, COP, flow_temperature)
from pypsaheat.optimization.optimize import OptimizationAccessor
import os

class HeatNetwork(pypsa.Network):
    """
    Extends the pypsa.Network class to include components and optimization routines for heat networks.
    """

    def __init__(self):
        """ Initialize the HeatNetwork class by calling the parent constructor and setting up heat-specific components. 
        """
        super().__init__()

        # Load component definitions from CSV files
        dir_name = os.path.dirname(__file__)
        pd.read_csv(os.path.join(dir_name, "components.csv"), index_col=0)

        heat_store_attrs = pd.read_csv(os.path.join(dir_name, 'component_attrs/heat_stores.csv')).set_index('attribute')
        heat_load_attrs = pd.read_csv(os.path.join(dir_name, 'component_attrs/heat_loads.csv')).set_index('attribute')
        heating_element_attrs = pd.read_csv(os.path.join(dir_name, 'component_attrs/heating_elements.csv')).set_index('attribute')
        heat_pump_attrs = pd.read_csv(os.path.join(dir_name, 'component_attrs/heat_pumps.csv')).set_index('attribute')

        self.components['HeatStore'] = {'list_name': 'heat_stores', 'attrs': heat_store_attrs}
        self.component_attrs['HeatStore'] = heat_store_attrs
        
        self.components['HeatLoad'] = {'list_name': 'heat_loads', 'attrs': heat_load_attrs}
        self.component_attrs['HeatLoad'] = heat_load_attrs

        self.components['HeatingElement'] = {'list_name': 'heating_elements', 'attrs': heating_element_attrs}
        self.component_attrs['HeatingElement'] = heating_element_attrs

        self.components['HeatPump'] = {'list_name': 'heat_pumps', 'attrs': heat_pump_attrs}
        self.component_attrs['HeatPump'] = heat_pump_attrs

        ##TODO: Die Implementierung als DataFrame sorgt für eine andere Sturktur als die in pypsa.components.py, 
        #sodass die Komponente nichts als funciton sondern als Varaible interpretiert wird. aNach Möglichkeit irgendwann ändern
        self.heat_stores = pd.DataFrame(columns=heat_store_attrs.index.drop('name'))
        self.heat_stores_t = {'T_mean': pd.DataFrame(index = self.snapshots), 
                              'e': pd.DataFrame(index = self.snapshots)
                              }

        self.heat_loads = pd.DataFrame(columns=heat_load_attrs.index.drop('name'))
        self.heat_loads_t = {'p_set': pd.DataFrame(index = self.snapshots), 
                             'T_demand': pd.DataFrame(index = self.snapshots),
                             'T_return': pd.DataFrame(index = self.snapshots),   
                             'mass_flow': pd.DataFrame(index = self.snapshots)
                             }

        self.heating_elements = pd.DataFrame(columns= heating_element_attrs.index.drop('name'))
        self.heating_elements_t = {'p': pd.DataFrame(index = self.snapshots)}

        p_heat_columns = pd.MultiIndex(levels=[[], []], codes=[[], []], names=["HeatPump", "Temperature"])
        COP_columns = pd.MultiIndex(levels=[[], []], codes=[[], []], names=["HeatPump", "Temperature"])
        self.heat_pumps = pd.DataFrame(columns=heat_pump_attrs.index.drop('name'))
        self.heat_pumps_t = {'p_heat': pd.DataFrame(index = self.snapshots, columns=p_heat_columns),
                             'p_elec': pd.DataFrame(index = self.snapshots),
                             'm_flow': pd.DataFrame(index = self.snapshots),
                             'T_source': pd.DataFrame(index = self.snapshots),
                             'COP': pd.DataFrame(index = self.snapshots, columns = COP_columns)
                             }


        ####TODO: Diese for-Schleife wurde aus dem pypsa.compoents.py übernommen, sie bereit die Component-Attribute auf, sodass n.add() funktioniert
        components = ['HeatStore', 'HeatLoad', 'HeatingElement', 'HeatPump']
           
        
        for component in components:
            # make copies to prevent unexpected sharing of variables
            attrs = self.component_attrs[component].copy()

            attrs["default"] = attrs.default.astype(object)
            attrs["static"] = attrs["type"] != "series"
            attrs["varying"] = attrs["type"].isin({"series", "static or series"})
            attrs["typ"] = (
                attrs["type"]
                .map(
                    {"boolean": bool, "int": int, "string": str, "list": list, "geometry": "geometry"}
                )
                .fillna(float)
            )
            attrs["dtype"] = (
                attrs["type"]
                .map(
                    {
                        "boolean": np.dtype(bool),
                        "int": np.dtype(int),
                        "string": np.dtype("O"),
                    }
                )
                .fillna(np.dtype(float))
            )

            bool_b = attrs.type == "boolean"
            if bool_b.any():
                attrs.loc[bool_b, "default"] = attrs.loc[bool_b, "default"].isin(
                    {True, "True"}
                )

            # exclude Network because it's not in a DF and has non-typical attributes
            if component != "Network":
                str_b = attrs.typ.apply(lambda x: x is str)
                attrs.loc[str_b, "default"] = attrs.loc[str_b, "default"].fillna("")
                for typ in (str, float, int):
                    typ_b = attrs.typ == typ
                    attrs.loc[typ_b, "default"] = attrs.loc[typ_b, "default"].astype(
                        typ
                    )                
                    
                self.component_attrs[component] = attrs
                self.components[component]["attrs"] = attrs

        # Initialize the optimization accessor
        self.optimize = OptimizationAccessor(self)

    def set_snapshots(self, snapshots):
        """ Set the snapshots for the network and initialize time series DataFrames for heat components.
        Parameters
        ----------
        snapshots
        """
        super().set_snapshots(snapshots)
        self.heat_stores_t['T_mean'] = pd.DataFrame(index = self.snapshots)
        self.heat_stores_t['e'] = pd.DataFrame(index = self.snapshots)
        self.heat_loads_t['p_set'] = pd.DataFrame(index = self.snapshots)
        self.heat_loads_t['T_demand'] = pd.DataFrame(index = self.snapshots)
        self.heat_loads_t['T_return'] = pd.DataFrame(index = self.snapshots)
        self.heat_loads_t['mass_flow'] = pd.DataFrame(index = self.snapshots)
        self.heating_elements_t['p'] = pd.DataFrame(index = self.snapshots)
        
        p_heat_columns = pd.MultiIndex(levels=[[], []], codes=[[], []], names=["HeatPump", "Temperature"])
        self.heat_pumps_t['p_heat'] = pd.DataFrame(index = self.snapshots, columns=p_heat_columns)
        self.heat_pumps_t['p_elec'] = pd.DataFrame(index = self.snapshots)
        self.heat_pumps_t['m_flow'] = pd.DataFrame(index = self.snapshots)
        self.heat_pumps_t['T_source'] = pd.DataFrame(index = self.snapshots)
        COP_columns = pd.MultiIndex(levels=[[], []], codes=[[], []], names=["HeatPump", "Temperature"])
        self.heat_pumps_t['COP'] = pd.DataFrame(index = self.snapshots, columns = COP_columns)


    def __repr__(self):
        header = "PyPSA Heat Network" + (f" '{self.name}'" if self.name else "")
        comps = {
            c.name: f" - {c.name}: {len(c.df)}"
            for c in self.iterate_components()
            if "Type" not in c.name and len(c.df)
        }
        
        comps_heat_dic = {'HeatStore': len(self.heat_stores),
              'HeatLoad': len(self.heat_loads),
              'HeatingElement': len(self.heating_elements),
              'HeatPump': len(self.heat_pumps)
              }

        comps_heat = {c: f" - {c}: {comps_heat_dic[c]}" for c in comps_heat_dic.keys() if comps_heat_dic[c] > 0}


        content = "\nComponents:"
        if comps or comps_heat:
            content += "\n" + "\n".join(comps[c] for c in sorted(comps))
            content += "\n" + "\n".join(comps_heat[c] for c in sorted(comps_heat))

        else:
            header = "Empty " + header
            content += " none"
        content += "\n"
        content += f"Snapshots: {len(self.snapshots)}"

        return header + content



############################################ Old Code ######################################################

def add_heat_bus(n, name, temperature_level):
    
    temp_level = list(map(int, sorted(temperature_level, reverse = True)))
    
    #adding buses for each level
    for T in temp_level:
        if 'heat_' + str(T) not in n.carriers.index:
            n.add('Carrier','heat_' + str(T))
        
        bus_name = name + '_T' + str(T)
        n.add('Bus', type = 'heat', name = bus_name, carrier = 'heat_'+str(T))


        new_col = {'T_nom': 'int', 'heat_name': 'string'}        
        for c in new_col:
            if c not in n.buses.columns:
                n.buses.loc[:,c] = pd.Series(dtype = new_col[c])

        n.buses.loc[bus_name,'T_nom'] = T
        n.buses.loc[bus_name,'heat_name'] = name


def add_heat_store(n, heat_bus, name, T_ref, diameter = 1, height = 2, storage_medium = 'water', T_amb = 25):

    volume = storage_dimensions(diameter, height)['V']

    #ToDo: exclude this values from here as they are needed in other analysis and optimization part as well
    cp_values = {'water': 0.001161388889/1000} #kWh/(kg*K)
    den_values = {'water': 1000} #kg/m3
    cp = cp_values[storage_medium] 
    den = den_values[storage_medium]
    
    new_col = {'heat_store_name': 'string', 'T_nom': 'int', 'volume': 'float64', 'T_ref': 'int', 'storage_medium': 'string'}    
    for c in new_col:
        if c not in n.stores.columns:
            n.stores.loc[:,c] = pd.Series(dtype = new_col[c])

    temp_level = n.buses.loc[n.buses['heat_name'] == heat_bus, 'T_nom'].astype(int).to_list()
    

    #adding links for each bus
    for v, T in enumerate(temp_level[:-1]):
        if 'heat_transfer' not in n.carriers.index:
            n.add('Carrier','heat_transfer')

        n.add('Link', 
              name = heat_bus +  '_trans_' + str(T) + 'to' + str(temp_level[v+1]),
              bus0 = heat_bus + '_T' + str(T),
              bus1 = heat_bus + '_T' + str(temp_level[v+1]),
              p_nom = 100000,
              carrier = 'heat_trans')

    for T in temp_level:
        
        dT = T - T_ref
        q_nom = dT * cp * den * volume #kWh nominal heat capacity
        
        heat_store_name = heat_bus + '_heat_store'
        heat_store_name_level = heat_store_name + '_T' + str(T)

        #calculating heat losses
        if T == max(temp_level) or T == min(temp_level):
            bot_top = True
        else: 
            bot_top = False

        rel_loss = stratified_storage_losses(T, diameter, storage_medium, 'MW', 0.1, T_amb, T_ref, bot_top = bot_top)

        n.add('Store', 
            bus = heat_bus + '_T' + str(T), #ToDO: strandardize naming for heat buses and stores
            name = heat_store_name_level, 
            carrier = 'heat_'+str(T), #ToDo standardize carrier naming
            e_nom = q_nom,
            standing_loss = rel_loss)
        
        n.stores.loc[heat_store_name_level,'heat_store_name'] = heat_store_name
        n.stores.loc[heat_store_name_level,'T_nom'] = T
        n.stores.loc[heat_store_name_level,'volume'] = volume
        n.stores.loc[heat_store_name_level,'T_ref'] = T_ref
        n.stores.loc[heat_store_name_level,'storage_medium'] = storage_medium

def add_heat_load(n, heat_bus, name,  p_set, T_amb, heater = 'radiator', T_hot_water = 55):
    temp_level = n.buses[n.buses['heat_name'] == heat_bus]['T_nom'].to_list()

    if heater == 'hot_water':
        T_sink = T_hot_water
        potential_T_levels = n.buses[n.buses['heat_name'] == heat_bus]['T_nom'].to_list()
        temp_level = [min([i for i in potential_T_levels if i >= T_hot_water])]
        T = temp_level[0]
        
        if 'hot_water_' + str(T) not in n.carriers.index:
            n.add('Carrier','hot_water_' + str(T))
    
        load_name = name + '_T' + str(T)
        bus_name = heat_bus + '_T' + str(int(T))
        n.add('Load', bus = bus_name, name = load_name, p_set = p_set, carrier = 'hot_water_' + str(T))

    else:
        temp_level = n.buses[n.buses['heat_name'] == heat_bus]['T_nom'].to_list()
        T_sink = flow_temperature(T_amb, heater)

        df = pd.DataFrame(columns = temp_level)
        df['T_sink'] = T_sink

        # Iterate over each column in the DataFrame (excluding 'T_sink')
        for col in df.columns.drop('T_sink'):
            col_value = int(col)
            
            # Update the column values based on the condition
            df[col] = df.apply(lambda row: p_set[row.name] if col_value >= row['T_sink'] else 0, axis=1)

        # Check for duplicate values in columns with lower column names
        for index, row in df.iterrows():
            for col in df.columns.drop('T_sink'):
                col_value = int(col)
                if df.at[index, col] != 0:
                    for lower_col in df.columns.drop('T_sink'):
                        lower_col_value = int(lower_col)
                        if lower_col_value < col_value and df.at[index, lower_col] == df.at[index, col]:
                            df.at[index, col] = 0
                            break

        new_col = {'T_nom': 'int', 'heat_bus': 'string', 'heater': 'string'}

        for c in new_col:
            if c not in n.loads.columns:
                n.loads.loc[:,c] = pd.Series(dtype = new_col[c])

        #adding load for each level
        for T in temp_level:
            if 'heat_' + str(T) not in n.carriers.index:
                n.add('Carrier','heat_' + str(T))
        
            load_name = name + '_T' + str(T)
            p_set = df.loc[:, T]
            bus_name = heat_bus + '_T' + str(int(T))
            n.add('Load', bus = bus_name, name = load_name, p_set = p_set, carrier = 'heat_' + str(T))

    for T in temp_level:
        
        load_name = name + '_T' + str(T)

        n.loads.loc[load_name,'T_nom'] = T
        n.loads.loc[load_name,'heat_bus'] = heat_bus
        n.loads.loc[load_name,'heater'] = heater

def add_heat_pump(n, name, bus0, heat_bus, p_nom, T_max, T_source):
    
    temp_level = n.buses[n.buses['heat_name'] == heat_bus]['T_nom'].to_list()


    new_col = {'T_nom': 'int', 'T_max': 'int', 'heat_bus': 'string'}

    for c in new_col:
        if c not in n.links.columns:
            n.links.loc[:,c] = pd.Series(dtype = new_col[c])

    car_heat_pump_bus = 'hp_bus'
    if car_heat_pump_bus not in n.carriers.index:
            n.add('Carrier',car_heat_pump_bus)
    
    hp_help_bus = name + '_hp_bus'
    n.add('Bus', name = hp_help_bus, carrier = car_heat_pump_bus)

    car_heat_pump = 'heat_pump'
    if car_heat_pump not in n.carriers.index:
            n.add('Carrier',car_heat_pump)

    n.add('Link', name = name, bus0 = bus0, bus1 = hp_help_bus, p_nom = p_nom, carrier = car_heat_pump)

    for T in temp_level:

        hp_car_T = car_heat_pump + '_' + str(T)

        if car_heat_pump + '_' + str(T) not in n.carriers.index:
            n.add('Carrier', hp_car_T)
    
        if T <= T_max:
                bus1 = n.buses[(n.buses['heat_name'] == heat_bus) & (n.buses['T_nom'] == T)].index[0]
                cop = COP(T, T_source)
                name = heat_bus  + '_hp_' + str(T) 
                n.add('Link', name = name, bus0 = hp_help_bus, bus1 = bus1, p_nom = p_nom, efficiency = cop, carrier = hp_car_T)

        n.links.loc[name,'T_nom'] = T
        n.links.loc[name,'T_max'] = T_max
        n.links.loc[name,'heat_bus'] = heat_bus


def add_direct_heater(n, name, bus0, heat_bus, p_nom, efficiency):
    
    T_highest = max(n.buses[n.buses['heat_name'] == heat_bus]['T_nom'].to_list())

    new_col = {'T_nom': 'int', 'heat_bus': 'string'}

    for c in new_col:
        if c not in n.links.columns:
            n.links.loc[:,c] = pd.Series(dtype = new_col[c])

    car_direct_heater = 'direct_heater'
    if car_direct_heater not in n.carriers.index:
            n.add('Carrier',car_direct_heater)

    bus1 = n.buses[(n.buses['heat_name'] == heat_bus) & (n.buses['T_nom'] == T_highest)].index[0]
    n.add('Link', name = name, bus0 = bus0, bus1 = bus1, p_nom = p_nom, carrier = car_direct_heater, efficiency = efficiency)

    n.links.loc[name,'T_nom'] = T_highest
    n.links.loc[name,'heat_bus'] = heat_bus