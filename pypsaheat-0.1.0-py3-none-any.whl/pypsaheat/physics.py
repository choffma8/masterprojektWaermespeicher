import pandas as pd
import numpy as np

def cp(storage_medium):
    cp_values = {'water': 0.001161388889} #kWH/(kg*K)
    return cp_values[storage_medium]

def den(storage_medium):   
    den_values = {'water': 1000} #kg/m3
    return den_values[storage_medium]

def iso_lambda(iso_material):
    '''Thermal conductivity of insulation material in W/(m*K)'''   
    iso_lambda_values = {'MW': 0.05, 'EPS': 0.05, 'XPS': 0.035, 'PUR': 0.04, 'CG': 0.055, 'PF': 0.045,
                  'WW': 0.065, 'EV': 0.07, 'EPB': 0.07}  #W/(m*K)
    return iso_lambda_values[iso_material]

def k_wall(wall_material):
    '''Thermal conductivity of wall material in W/(m*K)'''
    k_wall_values = {'steel': 50} #W/(m*K)
    return k_wall_values[wall_material]

def k(storage_medium):
    '''Thermal conductivity of storage medium in W/(m*K)'''
    k_values = {'water': 0.6} #W/(m*K)
    return k_values[storage_medium]


def nom_heat_capacity(dT, storage_medium, volume):
    cp = cp(storage_medium)
    den = den(storage_medium)

    q_nom = dT * cp * den * volume
    
    return q_nom


def flow_temperature(T_at_0C, T_gradient,T_amb):
    """
    Calculate the flow temperature for a heating system.
    Parameters
    ---------- 
    T_at_0C : float
        The flow temperature at 0°C ambient temperature.
    T_gradient : float
        The temperature gradient for the heating system (e.g. T_gradient = 0.5 means a temperature demand increase of 0.5K for each 1K decrease in ambient temperature).
    T_amb : float
        The ambient temperature.
    """

    T_sink = (T_at_0C - T_gradient * pd.Series(T_amb)).round(2)
    
    return T_sink


def flow_temperature_old(T_amb, heater):
    
    def T_sink_radiator(T_amb):
        T_sink = 45 - 1 * pd.Series(T_amb) # radiator heating temperature curve according to: https://doi.org/10.1038/s41597-019-0199-y
        return T_sink

    def T_sink_floor(T_amb):
        T_sink = 30 - 0.5 * T_amb # floor heating temperature curve according to: https://doi.org/10.1038/s41597-019-0199-y
        return T_sink

    if heater == 'radiator':
        T_sink = T_sink_radiator(T_amb)

    elif heater == 'floor':
        T_sink = T_sink_floor(T_amb)

    return T_sink

def COP(up_T, low_T, heat_source = 'air', cop_model = 0):
    '''Getting COP series from temperature data of flow (up_T) and environmental temperature (low_T) data.

    Parameters
    ----------- 
    up_T : upper Temperature value in °C for output temperature of heat pump (int or float)
    low_T : lower Temperature value in °C for input temperature from environmental heat source (list)
    heat_source : environmental heat source ('air', 'ground'); default: 'air'
    cop_model : chose between model types by different publications {0: Staffel et al. DOI: 10.1039/c2ee22653g}; default: 0 

    Returns
    -----------
    List of COP values for heat pump model
    '''
    
    dT = up_T - low_T

    ##defining different COP models
    def ashp_staffel_et_al(dT):
        '''model by DOI: 10.1039/c2ee22653g; COP model for air source heat pumps; valid for 15K<= dT <= 60K'''
        return 6.81-0.121*dT+0.00063*dT**2
    def gshp_staffel_et_al(dT):
        '''model by DOI: 10.1039/c2ee22653g; COP model for ground source heat pumps; valid for 20K<= dT <= 60K'''
        return 8.77-0.15*dT+0.000734*dT**2

    #list for different COP models
    cop_models = [{'air':ashp_staffel_et_al, 'ground': gshp_staffel_et_al}]

    # Select the  COP model function based on the heat source and cop_model
    cop_function = cop_models[int(cop_model)][heat_source]

    # Apply the selected COP function to the temperature difference
    cop_data = pd.Series(data = [cop_function(temp_diff) for temp_diff in dT], index = dT.index).round(2)

    return cop_data

def get_diameter(A_base):
    diameter = 2 * (A_base/np.pi)**0.5
    return diameter

def get_circumference(A_base):
    circumference = 2 * np.pi * (A_base/np.pi)**0.5
    return circumference


def storage_dimensions(diameter, height): 

    A_sur = round(diameter * np.pi * height, 2)
    A_base = round((diameter/2)**2 * np.pi, 2) #m2
    V = round(A_base * height, 3) #m3

    return {'A_base': A_base, 'A_sur': A_sur, 'V': V}

def storage_height(diameter, volume):
    height = volume / (np.pi * (diameter/2)**2)
    return height


def stratified_storage_losses(T_nom, diameter, storage_medium ,iso_material, iso_thickness, T_amb, T_ref, bot_top = False):
    	
    iso_lambda_store = iso_lambda(iso_material)
    cp_store = cp(storage_medium)
    den_store = den(storage_medium)
    dT = T_nom - T_ref

    U = (1/(iso_thickness / iso_lambda_store)) /1000000 #MW/(m2*K) ToDo: Konvektionsverluste durch wärmeübergangskoeffizienten noch zu U-Wert berechnung hinzufügen
    
    #check if layer is max or min
    if bot_top == True:
        base_factor = 1 #activate losses for top and bottom layer over additional surface
    else:
        base_factor = 0
    
    loss = round(U * (T_nom - T_amb) * (4 /(diameter * den_store * cp_store * dT) + base_factor * 0.25 * np.pi * diameter**2), 10)
    
    return loss

def storage_heat_exchange(heat_store, diameter, height, storage_medium = 'water', wall_thickness = 0.01, wall_material = 'steel'):
    
    A_tank = storage_dimensions(diameter, height) #cross section area of tank fluid
    A_wall = 0.25 * np.pi * (diameter + 2 * wall_thickness) - A_tank # cross section area of wall

    k_wall_store = k_wall[wall_material]

    dk = k_wall_store * (A_wall/A_tank) #thermal konduktivity of wall

    
def get_inlet_outlet_layer(n, in_out_height, hs):
    '''Function to get the inlet and outlet layer of a heat store based on the relative height of inlet and outlet.
    Parameters
    ----------
    n : pypsa.Network
        The PyPSA network object containing the heat store.
    in_out_height : float 
        The relative height of the inlet or outlet (0 to 1).
    hs : str 
        The name of the heat store.

    Returns
    -------
    int
        The layer index corresponding to the inlet or outlet height.        
    '''

    n_layer = n.heat_stores.loc[hs, 'N_layer']
    hs_height = n.heat_stores.loc[hs, 'height']
    layer_height = hs_height / n_layer
    connect_height = in_out_height * hs_height
    
    return int(n_layer - connect_height // layer_height)



    















